import AllRoutes from "./AllRoutes";
import Navbar from "./components/navbar";
import HomePage from "./components/homepage";
import SearchProvider from "./searchContext";

import "./App.css";

function App(){
    return(
     <AllRoutes/>
    );
       
 
}
export default App;

