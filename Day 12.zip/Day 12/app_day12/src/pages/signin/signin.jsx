import React from "react";


function Signin(){
    return (
        <div>
        <input type="text" placeholder="Enter email"/>
        <input type="text" placeholder="Enter pass"/>
        <button>Sign In</button>
        </div>
    );
    
}
export default Signin;